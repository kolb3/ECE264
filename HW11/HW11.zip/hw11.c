#include "hw10.h"
//Modify this file
#ifdef TEST_MAIN

int main(int argc, char **argv){
  // check the arguments - please read readme about validity of arguments
  // check radius and epsilon values -  read readme for the validity of argument
  // open the BMP file
  // convert to gray scale
	// check for error in converting to gray scale

  // call adaptive threshold function
  // check for errors after calling adaptive threshold
	// write the adaptive threshold image to file
	// free all the images
	return EXIT_SUCCESS;
}

#endif
